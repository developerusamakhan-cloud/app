<?php
/**
 * Chat widget: floating launcher, inline shortcode and shared markup.
 *
 * @package AI_Site_Assistant
 */

defined( 'ABSPATH' ) || exit;

/**
 * Front end.
 */
class Aisa_Frontend {

	/**
	 * Whether an inline chat was printed on this page.
	 *
	 * @var bool
	 */
	private static $inline_rendered = false;

	/**
	 * Whether the widget assets and configuration were enqueued on this request.
	 *
	 * @var bool
	 */
	private static $enqueued = false;

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register' ) );
		add_action( 'wp_footer', array( __CLASS__, 'render_floating' ) );
		add_shortcode( 'aisa_chat', array( __CLASS__, 'shortcode' ) );
		add_action( 'template_redirect', array( __CLASS__, 'popout' ), 1 );
	}

	/**
	 * Languages a visitor can pick in the widget menu.
	 *
	 * @return array<string, array{native:string,en:string,rtl:bool}>
	 */
	public static function languages() {
		$list = array(
			'en' => array( 'English', 'English', false ),
			'es' => array( 'Español', 'Spanish', false ),
			'fr' => array( 'Français', 'French', false ),
			'de' => array( 'Deutsch', 'German', false ),
			'pt' => array( 'Português', 'Portuguese', false ),
			'it' => array( 'Italiano', 'Italian', false ),
			'nl' => array( 'Nederlands', 'Dutch', false ),
			'tr' => array( 'Türkçe', 'Turkish', false ),
			'pl' => array( 'Polski', 'Polish', false ),
			'ru' => array( 'Русский', 'Russian', false ),
			'ar' => array( 'العربية', 'Arabic', true ),
			'ur' => array( 'اردو', 'Urdu', true ),
			'hi' => array( 'हिन्दी', 'Hindi', false ),
			'zh' => array( '中文', 'Chinese', false ),
			'ja' => array( '日本語', 'Japanese', false ),
			'ko' => array( '한국어', 'Korean', false ),
		);
		$out  = array();
		foreach ( $list as $code => $row ) {
			$out[ $code ] = array(
				'native' => $row[0],
				'en'     => $row[1],
				'rtl'    => $row[2],
			);
		}
		return (array) apply_filters( 'aisa_languages', $out );
	}

	/**
	 * Link behind the "Powered by" line: the author website from the Branding settings.
	 *
	 * @return string
	 */
	public static function brand_link() {
		return (string) Aisa_Brand::get( 'author_url' );
	}

	/**
	 * Whether the badge shows (owner opted in, add-ons can hide it).
	 *
	 * @return bool
	 */
	public static function show_badge() {
		return (bool) apply_filters( 'aisa_show_badge', (bool) Aisa_Settings::get( 'show_badge', 0 ) );
	}

	/**
	 * Widget menu items.
	 *
	 * @return array[] Each: id, label, and url for links.
	 */
	public static function menu_items() {
		$s     = Aisa_Settings::all();
		$items = array(
			array(
				'id'    => 'name',
				'label' => __( 'Change name', 'ai-site-assistant' ),
			),
		);
		if ( ! empty( $s['transcript_enabled'] ) && ! empty( $s['logs_enabled'] ) ) {
			$items[] = array(
				'id'    => 'transcript',
				'label' => __( 'Email transcript', 'ai-site-assistant' ),
			);
		}
		if ( ! empty( $s['show_sound_button'] ) ) {
			$items[] = array(
				'id'    => 'sound',
				'label' => __( 'Sound', 'ai-site-assistant' ),
			);
		}
		if ( ! empty( $s['language_menu'] ) ) {
			$items[] = array(
				'id'    => 'language',
				'label' => __( 'Language', 'ai-site-assistant' ),
			);
		}
		$items[] = array(
			'id'    => 'popout',
			'label' => __( 'Pop out', 'ai-site-assistant' ),
		);
		if ( ! empty( $s['show_reset_button'] ) ) {
			$items[] = array(
				'id'    => 'reset',
				'label' => Aisa_I18n::get( 'reset_label' ),
			);
		}

		/**
		 * Filters the widget menu. Each item: id, label, optional url.
		 *
		 * @param array $items Items.
		 */
		return array_values( (array) apply_filters( 'aisa_widget_menu', $items ) );
	}

	/**
	 * Pop-out window: the chat on its own page (?aisa_popout=1).
	 *
	 * @return void
	 */
	public static function popout() {
		if ( empty( $_GET['aisa_popout'] ) || ! Aisa_Settings::get( 'enabled' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		show_admin_bar( false );
		nocache_headers();
		wp_register_style( 'aisa-widget', AISA_URL . 'assets/css/widget.css', array(), AISA_VERSION );
		wp_register_script( 'aisa-widget', AISA_URL . 'assets/js/widget.js', array(), AISA_VERSION, true );
		wp_register_style( 'aisa-popout', AISA_URL . 'assets/css/popout.css', array( 'aisa-widget' ), AISA_VERSION );
		self::enqueue();
		wp_enqueue_style( 'aisa-popout' );
		$bot = Aisa_I18n::get( 'bot_name' );
		?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?php echo esc_html( $bot . ' | ' . wp_strip_all_tags( get_bloginfo( 'name' ) ) ); ?></title>
		<?php wp_print_styles(); ?>
</head>
<body class="aisa-popout">
		<?php echo wp_kses( self::markup( 'inline', 0, true ), Aisa_Kses::html() ); ?>
		<?php wp_print_scripts(); ?>
</body>
</html>
		<?php
		exit;
	}

	/**
	 * Register assets; enqueue them where the widget shows.
	 *
	 * @return void
	 */
	public static function register() {
		self::register_assets();
		if ( self::should_show() ) {
			self::enqueue();
		}
	}

	/**
	 * Register the widget style and script (once).
	 *
	 * @return void
	 */
	private static function register_assets() {
		if ( wp_script_is( 'aisa-widget', 'registered' ) ) {
			return;
		}
		wp_register_style( 'aisa-widget', AISA_URL . 'assets/css/widget.css', array(), AISA_VERSION );
		wp_register_script( 'aisa-widget', AISA_URL . 'assets/js/widget.js', array(), AISA_VERSION, true );
	}

	/**
	 * Enqueue assets and the widget configuration once.
	 *
	 * @return void
	 */
	public static function enqueue() {
		// Block themes render [aisa_chat] before wp_enqueue_scripts, so register here too.
		// A flag, not wp_script_is( 'enqueued' ): that is also true when an add-on script
		// depends on the widget, which would skip the configuration below.
		if ( self::$enqueued ) {
			return;
		}
		self::$enqueued = true;
		self::register_assets();
		wp_enqueue_style( 'aisa-widget' );
		wp_enqueue_script( 'aisa-widget' );
		wp_add_inline_script( 'aisa-widget', 'window.AisaConfig = ' . wp_json_encode( self::config() ) . ';', 'before' );
		if ( Aisa_Settings::get( 'lead_enabled' ) && '' !== (string) Aisa_Settings::get( 'turnstile_site_key' ) && '' !== (string) Aisa_Settings::get( 'turnstile_secret' ) ) {
			wp_enqueue_script( 'aisa-turnstile', 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit', array(), null, array( 'in_footer' => true, 'strategy' => 'async' ) ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion,PluginCheck.CodeAnalysis.EnqueuedResourceOffloading.OffloadedContent -- Cloudflare Turnstile must load from Cloudflare; opt-in and listed under External services.
		}

		/**
		 * Fires after the widget assets were enqueued. Add-ons enqueue theirs here.
		 */
		do_action( 'aisa_enqueue_widget' );
	}

	/**
	 * Configuration passed to widget.js.
	 *
	 * @return array
	 */
	public static function config() {
		$s     = Aisa_Settings::all();
		$t     = array( 'Aisa_I18n', 'get' );
		$brand = sanitize_hex_color( (string) $s['brand_color'] );
		$brand = $brand ? $brand : '#4F46E5';
		$bot   = call_user_func( $t, 'bot_name' );
		$lines = preg_split( '/\r\n|\r|\n/', call_user_func( $t, 'suggested_questions' ) );

		$config = array(
			'rest'         => esc_url_raw( rest_url( Aisa_REST::NS . '/' ) ),
			'version'      => AISA_VERSION,
			'brand'        => $brand,
			'onBrand'      => Aisa_Contrast::text_on( $brand ),
			'position'     => 'left' === $s['position'] ? 'left' : 'right',
			'width'        => min( 720, max( 320, absint( $s['chat_width'] ) ) ),
			'height'       => min( 900, max( 480, absint( $s['chat_height'] ) ) ),
			'pageLanguage' => Aisa_I18n::page_language(),
			'turnstile'    => ( '' !== (string) $s['turnstile_site_key'] && '' !== (string) $s['turnstile_secret'] ) ? (string) $s['turnstile_site_key'] : '',
			'badge'        => self::show_badge(),
			'badgeUrl'     => self::brand_link(),
			'menu'         => ! empty( $s['widget_menu'] ) ? self::menu_items() : array(),
			'languages'    => self::languages(),
			'popoutUrl'    => add_query_arg( 'aisa_popout', '1', home_url( '/' ) ),
			'devices'      => (string) $s['devices'],
			'flags'        => array(
				'fullScreen'   => ! empty( $s['full_screen_enabled'] ),
				'mobileFull'   => ! empty( $s['mobile_full_screen'] ),
				'sound'        => ! empty( $s['show_sound_button'] ),
				'soundDefault' => ! empty( $s['sound_default'] ),
				'timestamps'   => ! empty( $s['show_timestamps'] ),
				'copy'         => ! empty( $s['show_message_tools'] ),
				'feedback'     => ! empty( $s['feedback_enabled'] ) && ! empty( $s['logs_enabled'] ),
				'lead'         => ! empty( $s['lead_enabled'] ),
				'leadAskFirst' => ! empty( $s['lead_ask_first'] ),
				'requireName'  => ! empty( $s['lead_require_name'] ),
				'requireEmail' => ! empty( $s['lead_require_email'] ),
				'requirePhone' => ! empty( $s['lead_require_phone'] ),
				'consent'      => ! empty( $s['lead_consent_enabled'] ),
				'handoff'      => ! empty( $s['handoff_enabled'] ) && '' !== (string) $s['handoff_url'],
			),
			'handoffUrl'   => esc_url_raw( (string) $s['handoff_url'] ),
			'suggestions'  => array_slice( array_values( array_filter( array_map( 'trim', (array) $lines ) ) ), 0, 4 ),
			'text'         => array(
				'botName'        => $bot,
				'welcome'        => call_user_func( $t, 'welcome_message' ),
				'placeholder'    => call_user_func( $t, 'placeholder' ),
				'online'         => call_user_func( $t, 'online_label' ),
				'typing'         => str_replace( '{bot}', $bot, call_user_func( $t, 'typing_label' ) ),
				'leadPrompt'     => call_user_func( $t, 'lead_prompt' ),
				'leadYes'        => call_user_func( $t, 'lead_yes_label' ),
				'leadNo'         => call_user_func( $t, 'lead_no_label' ),
				'leadDecline'    => call_user_func( $t, 'lead_decline_reply' ),
				'leadIntro'      => call_user_func( $t, 'lead_form_intro' ),
				'leadTitle'      => call_user_func( $t, 'lead_title' ),
				'leadButton'     => call_user_func( $t, 'lead_button' ),
				'leadSuccess'    => call_user_func( $t, 'lead_success' ),
				'consent'        => call_user_func( $t, 'lead_consent_text' ),
				'privacy'        => call_user_func( $t, 'privacy_notice' ),
				'handoff'        => call_user_func( $t, 'handoff_label' ),
				'sources'        => call_user_func( $t, 'sources_label' ),
				'name'           => call_user_func( $t, 'name_label' ),
				'email'          => call_user_func( $t, 'email_label' ),
				'phone'          => call_user_func( $t, 'phone_label' ),
				'sending'        => call_user_func( $t, 'sending_label' ),
				'leadSaved'      => call_user_func( $t, 'success_title' ),
				'reference'      => call_user_func( $t, 'reference_label' ),
				'continue'       => call_user_func( $t, 'continue_chat_label' ),
				'error'          => call_user_func( $t, 'generic_error' ),
				'connection'     => call_user_func( $t, 'connection_error' ),
				'leadError'      => call_user_func( $t, 'lead_error' ),
				'copy'           => call_user_func( $t, 'copy_label' ),
				'copied'         => call_user_func( $t, 'copied_label' ),
				'helpful'        => call_user_func( $t, 'helpful_label' ),
				'notHelpful'     => call_user_func( $t, 'not_helpful_label' ),
				'resetConfirm'   => call_user_func( $t, 'reset_confirm' ),
				'send'           => __( 'Send message', 'ai-site-assistant' ),
				'message'        => __( 'Message', 'ai-site-assistant' ),
				'poweredBy'      => __( 'Powered by {brand}', 'ai-site-assistant' ),
				'menu'           => __( 'Chat menu', 'ai-site-assistant' ),
				'yourName'       => __( 'Your name', 'ai-site-assistant' ),
				'save'           => __( 'Save', 'ai-site-assistant' ),
				'cancel'         => __( 'Cancel', 'ai-site-assistant' ),
				/* translators: %s: visitor name */
				'nameSaved'      => __( 'Thanks, %s. Nice to meet you.', 'ai-site-assistant' ),
				'transcriptTitle' => __( 'Email this chat to me', 'ai-site-assistant' ),
				'transcriptConsent' => __( 'Send me this chat and let the team contact me about my questions.', 'ai-site-assistant' ),
				'transcriptSend' => __( 'Send transcript', 'ai-site-assistant' ),
				'autoLanguage'   => __( 'Auto (match my messages)', 'ai-site-assistant' ),
				/* translators: %s: language name */
				'languageSet'    => __( 'Replies will be in %s.', 'ai-site-assistant' ),
				'soundOn'        => __( 'Sound on', 'ai-site-assistant' ),
				'soundOff'       => __( 'Sound off', 'ai-site-assistant' ),
				'websiteField'   => __( 'Leave this field empty', 'ai-site-assistant' ),
				'securityCheck'  => __( 'Please complete the security check.', 'ai-site-assistant' ),
				'chatWindow'     => __( 'Chat window', 'ai-site-assistant' ),
				'openChat'       => __( 'Open chat', 'ai-site-assistant' ),
			),
		);

		/**
		 * Filters the widget configuration. an add-on adds proactive messages,
		 * business hours and streaming here.
		 *
		 * @param array $config Configuration.
		 */
		return (array) apply_filters( 'aisa_widget_config', $config );
	}

	/**
	 * Print the floating widget.
	 *
	 * @return void
	 */
	public static function render_floating() {
		if ( self::$inline_rendered || ! self::should_show() ) {
			return;
		}
		echo wp_kses( self::markup( 'floating' ), Aisa_Kses::html() );
	}

	/**
	 * [aisa_chat mode="inline"] shortcode.
	 *
	 * @param array|string $atts Attributes.
	 * @return string
	 */
	public static function shortcode( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'mode'   => 'inline',
				'height' => '',
			),
			$atts,
			'aisa_chat'
		);
		if ( ! Aisa_Settings::get( 'enabled' ) || is_admin() ) {
			return '';
		}
		self::enqueue();
		$mode = 'floating' === $atts['mode'] ? 'floating' : 'inline';
		if ( 'inline' === $mode ) {
			self::$inline_rendered = true;
		}
		return self::markup( $mode, absint( $atts['height'] ) );
	}

	/**
	 * Whether the floating widget shows on this request.
	 *
	 * @return bool
	 */
	public static function should_show() {
		$s = Aisa_Settings::all();
		if ( is_admin() || empty( $s['enabled'] ) || is_feed() || is_embed() ) {
			return false;
		}
		if ( ( 'logged_in' === $s['show_to'] && ! is_user_logged_in() ) || ( 'logged_out' === $s['show_to'] && is_user_logged_in() ) ) {
			return false;
		}
		$hidden = array_map( 'absint', (array) $s['hidden_page_ids'] );
		if ( $hidden && is_singular() && in_array( (int) get_queried_object_id(), $hidden, true ) ) {
			return false;
		}
		$paths = trim( (string) $s['hidden_url_paths'] );
		if ( '' !== $paths ) {
			$uri     = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
			$current = untrailingslashit( '/' . ltrim( (string) wp_parse_url( $uri, PHP_URL_PATH ), '/' ) );
			$current = '' === $current ? '/' : $current;
			foreach ( preg_split( '/\r\n|\r|\n/', $paths ) as $path ) {
				$path = trim( $path );
				if ( '' === $path ) {
					continue;
				}
				$path = untrailingslashit( '/' . ltrim( (string) wp_parse_url( $path, PHP_URL_PATH ), '/' ) );
				$path = '' === $path ? '/' : $path;
				if ( $current === $path || ( '/' !== $path && 0 === strpos( $current . '/', $path . '/' ) ) ) {
					return false;
				}
			}
		}

		/**
		 * Filters whether the floating widget shows.
		 *
		 * @param bool $show Show.
		 */
		return (bool) apply_filters( 'aisa_show_widget', true );
	}

	/**
	 * Launcher and header icons.
	 *
	 * @param string $icon Icon name.
	 * @return string SVG.
	 */
	public static function icon( $icon ) {
		$open = '<svg class="twc-icon" viewBox="0 0 32 32" aria-hidden="true" focusable="false">';
		switch ( $icon ) {
			case 'chat_dots':
				$inner = '<path class="twc-stroke" d="M6.5 7.5h19A3.5 3.5 0 0 1 29 11v9a3.5 3.5 0 0 1-3.5 3.5H15l-6.5 4v-4h-2A3.5 3.5 0 0 1 3 20v-9a3.5 3.5 0 0 1 3.5-3.5Z"/><circle cx="11" cy="15.5" r="1.4"/><circle cx="16" cy="15.5" r="1.4"/><circle cx="21" cy="15.5" r="1.4"/>';
				break;
			case 'headset':
				$inner = '<path class="twc-stroke" d="M6 17v-2a10 10 0 0 1 20 0v2"/><path class="twc-stroke" d="M6 17h3v8H7.5A2.5 2.5 0 0 1 5 22.5v-3A2.5 2.5 0 0 1 7.5 17H9M26 17h-3v8h1.5a2.5 2.5 0 0 0 2.5-2.5v-3a2.5 2.5 0 0 0-2.5-2.5H23M23 25c0 2-2 3-5 3h-2"/>';
				break;
			case 'question':
				$inner = '<path class="twc-stroke" d="M7 7h18a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H15l-6 4v-4H7a3 3 0 0 1-3-3V10a3 3 0 0 1 3-3Z"/><path class="twc-stroke" d="M12.8 13a3.3 3.3 0 1 1 5.9 2c-1.45 1.55-2.7 1.65-2.7 3.5"/><circle cx="16" cy="21.2" r="1.1"/>';
				break;
			case 'spark_chat':
				$inner = '<path class="twc-stroke" d="M7.5 6.5h17A3.5 3.5 0 0 1 28 10v9a3.5 3.5 0 0 1-3.5 3.5H15l-6 4v-4H7.5A3.5 3.5 0 0 1 4 19v-9a3.5 3.5 0 0 1 3.5-3.5Z"/><path d="M18.6 10.2c.25 1.55 1.25 2.55 2.8 2.8-1.55.25-2.55 1.25-2.8 2.8-.25-1.55-1.25-2.55-2.8-2.8 1.55-.25 2.55-1.25 2.8-2.8Z"/><circle cx="11" cy="14.5" r="1.15"/>';
				break;
			case 'aisa':
			default:
				// Default mark: a bubble with three rising dots.
				$inner = '<path class="twc-stroke" d="M8 4.5h16A5.5 5.5 0 0 1 29.5 10v10A5.5 5.5 0 0 1 24 25.5H13.5L7.5 30v-4.6A5.5 5.5 0 0 1 2.5 20V10A5.5 5.5 0 0 1 8 4.5Z"/><circle cx="10.2" cy="18.6" r="2"/><circle cx="16" cy="15.3" r="2"/><circle cx="21.8" cy="11.5" r="2.4"/>';
		}
		return $open . $inner . '</svg>';
	}

	/**
	 * Assistant avatar.
	 *
	 * @param array $s Settings.
	 * @return string HTML.
	 */
	private static function avatar( array $s ) {
		$type = (string) $s['avatar_type'];
		if ( 'custom' === $type && ! empty( $s['avatar_url'] ) ) {
			return '<img src="' . esc_url( $s['avatar_url'] ) . '" alt="" width="36" height="36" loading="lazy">';
		}
		if ( 'initials' === $type ) {
			$name    = trim( Aisa_I18n::get( 'bot_name' ) );
			$letters = function_exists( 'mb_substr' ) ? mb_strtoupper( mb_substr( $name, 0, 1 ) ) : strtoupper( substr( $name, 0, 1 ) );
			return '<span class="twc-avatar__text">' . esc_html( '' !== $letters ? $letters : 'A' ) . '</span>';
		}
		if ( 'headset' === $type || 'chat' === $type ) {
			return self::icon( 'chat' === $type ? 'chat_dots' : 'headset' );
		}
		return self::icon( 'aisa' );
	}

	/**
	 * Widget markup.
	 *
	 * @param string $mode   floating|inline.
	 * @param int    $height Inline height in px.
	 * @param bool   $popout Rendered in the pop-out window.
	 * @return string
	 */
	public static function markup( $mode, $height = 0, $popout = false ) {
		$s        = Aisa_Settings::all();
		$label    = trim( Aisa_I18n::get( 'launcher_label' ) );
		$bot      = Aisa_I18n::get( 'bot_name' );
		$tool     = static function ( $class, $key, $svg, $extra = '' ) {
			$text = Aisa_I18n::get( $key );
			return '<button type="button" class="twc-head-btn ' . esc_attr( $class ) . '" aria-label="' . esc_attr( $text ) . '" title="' . esc_attr( $text ) . '"' . $extra . '>' . $svg . '</button>';
		};
		$svg      = static function ( $paths ) {
			return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $paths . '</svg>';
		};
		$tools    = '';
		$menu     = ! empty( $s['widget_menu'] );
		if ( $menu ) {
			$tools .= '<button type="button" class="twc-head-btn twc-menu-btn" aria-haspopup="menu" aria-expanded="false" aria-label="' . esc_attr__( 'Chat menu', 'ai-site-assistant' ) . '" title="' . esc_attr__( 'Chat menu', 'ai-site-assistant' ) . '">' . $svg( '<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>' ) . '</button>';
		}
		if ( ! $menu && ! empty( $s['show_reset_button'] ) ) {
			$tools .= $tool( 'twc-reset', 'reset_label', $svg( '<path d="M4 4v6h6"/><path d="M5.5 15a7.5 7.5 0 1 0 .8-7.7L4 10"/>' ) );
		}
		if ( ! $menu && ! empty( $s['show_sound_button'] ) ) {
			$tools .= $tool( 'twc-sound', 'sound_label', $svg( '<g class="twc-on"><path d="M11 5 6 9H3v6h3l5 4V5Z"/><path d="M15 9.5a4 4 0 0 1 0 5"/><path d="M17.5 7a7.5 7.5 0 0 1 0 10"/></g><g class="twc-off"><path d="M11 5 6 9H3v6h3l5 4V5Z"/><path d="m16 10 5 5"/><path d="m21 10-5 5"/></g>' ), ' aria-pressed="false"' );
		}
		if ( 'floating' === $mode && ! empty( $s['full_screen_enabled'] ) ) {
			$tools .= $tool( 'twc-expand', 'expand_label', $svg( '<g class="twc-on"><path d="M8 3H3v5"/><path d="M16 3h5v5"/><path d="M8 21H3v-5"/><path d="M16 21h5v-5"/></g><g class="twc-off"><path d="M8 8H3V3"/><path d="M16 8h5V3"/><path d="M8 16H3v5"/><path d="M16 16h5v5"/></g>' ), ' aria-pressed="false"' );
		}
		if ( 'floating' === $mode && ! empty( $s['show_minimize_button'] ) ) {
			$tools .= $tool( 'twc-minimize', 'minimize_label', $svg( '<path d="M5 12h14"/>' ) );
		}
		if ( 'floating' === $mode ) {
			$tools .= $tool( 'twc-close', 'close_label', $svg( '<path d="m6 6 12 12"/><path d="M18 6 6 18"/>' ) );
		}

		ob_start();
		?>
		<div class="twc twc--<?php echo esc_attr( $mode ); ?><?php echo esc_attr( $popout ? ' twc--popout' : '' ); ?><?php echo esc_attr( ! empty( $s['launcher_pulse'] ) ? ' twc--pulse' : '' ); ?><?php echo esc_attr( 'gradient' === $s['header_style'] ? ' twc--gradient' : '' ); ?>" data-aisa-chat="<?php echo esc_attr( $mode ); ?>"<?php if ( $height ) : ?> style="--twc-inline-height:<?php echo absint( $height ); ?>px"<?php endif; ?>>
			<?php if ( 'floating' === $mode ) : ?>
				<div class="twc-launcher-wrap">
					<?php if ( '' !== $label ) : ?>
						<span class="twc-launcher-label" dir="auto"><?php echo esc_html( $label ); ?></span>
					<?php endif; ?>
					<button class="twc-launcher" type="button" aria-expanded="false" aria-label="<?php echo esc_attr( '' !== $label ? $label : __( 'Open chat', 'ai-site-assistant' ) ); ?>">
						<?php echo wp_kses( self::icon( (string) $s['launcher_icon'] ), Aisa_Kses::svg() ); ?>
					</button>
				</div>
			<?php endif; ?>
			<section class="twc-panel" role="dialog" aria-label="<?php echo esc_attr( $bot ); ?>"<?php echo 'floating' === $mode ? ' hidden' : ''; ?>>
				<header class="twc-header">
					<div class="twc-avatar"><?php echo wp_kses( self::avatar( $s ), Aisa_Kses::html() ); ?></div>
					<div class="twc-identity">
						<strong class="twc-name" dir="auto"><?php echo esc_html( $bot ); ?></strong>
						<span class="twc-status" dir="auto"><?php echo esc_html( Aisa_I18n::get( 'online_label' ) ); ?></span>
					</div>
					<div class="twc-tools"><?php echo wp_kses( $tools, Aisa_Kses::html() ); ?></div>
				</header>
				<div class="twc-menu" role="menu" aria-label="<?php esc_attr_e( 'Chat menu', 'ai-site-assistant' ); ?>" hidden></div>
				<div class="twc-messages" role="log" aria-live="polite" aria-relevant="additions"></div>
				<div class="twc-suggestions"></div>
				<form class="twc-compose" novalidate>
					<label class="twc-sr" for="twc-input-<?php echo esc_attr( $mode ); ?>"><?php esc_html_e( 'Message', 'ai-site-assistant' ); ?></label>
					<textarea id="twc-input-<?php echo esc_attr( $mode ); ?>" rows="1" maxlength="4000" dir="auto" placeholder="<?php echo esc_attr( Aisa_I18n::get( 'placeholder' ) ); ?>"></textarea>
					<button type="submit" class="twc-send" aria-label="<?php esc_attr_e( 'Send message', 'ai-site-assistant' ); ?>"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 12h13"/><path d="m13 6 6 6-6 6"/></svg></button>
				</form>
				<div class="twc-foot" dir="auto"></div>
			</section>
		</div>
		<?php
		return (string) ob_get_clean();
	}
}
