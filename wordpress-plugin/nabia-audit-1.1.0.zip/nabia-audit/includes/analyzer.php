<?php
/**
 * Website analyzer: fetches a page and scores Design, SEO, Content and Speed & Security.
 *
 * Every check returns: label, status (pass|warn|fail), weight (importance 1 to 3),
 * found (what we saw) and fix (what to do). Scores are weighted: pass = 1, warn = 0.5, fail = 0.
 *
 * @package NabiaAudit
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Category meta: title, weight in the overall score and a short "why it matters".
 *
 * @return array
 */
function nwa_categories() {
	return array(
		'design'  => array(
			'title'  => 'Design & User Experience',
			'short'  => 'Design',
			'weight' => 25,
			'why'    => 'Visitors decide in about 50 milliseconds whether a website feels trustworthy. A clear, mobile friendly design with obvious next steps turns visitors into enquiries.',
		),
		'seo'     => array(
			'title'  => 'SEO',
			'short'  => 'SEO',
			'weight' => 30,
			'why'    => 'SEO decides whether people can find you on Google at all. These are the on page basics Google reads first on every visit.',
		),
		'content' => array(
			'title'  => 'Content',
			'short'  => 'Content',
			'weight' => 20,
			'why'    => 'Good content answers questions, builds trust and gives Google something to rank. It is also what finally convinces a visitor to contact you.',
		),
		'speed'   => array(
			'title'  => 'Speed & Security',
			'short'  => 'Speed',
			'weight' => 25,
			'why'    => 'Slow or insecure websites lose visitors and rankings. Every extra second of loading time costs conversions, and browsers warn people about unsafe sites.',
		),
	);
}

/**
 * Normalise a URL typed by a visitor.
 *
 * @param string $url Raw input.
 * @return string Empty when invalid.
 */
function nwa_normalize_url( $url ) {
	$url = trim( (string) $url );
	if ( '' === $url ) {
		return '';
	}
	if ( ! preg_match( '#^https?://#i', $url ) ) {
		$url = 'https://' . $url;
	}
	$url   = esc_url_raw( $url, array( 'http', 'https' ) );
	$parts = wp_parse_url( $url );
	if ( empty( $parts['host'] ) || false === strpos( $parts['host'], '.' ) ) {
		return '';
	}
	return $url;
}

/**
 * Seconds left for this audit (hosts often stop PHP after 30 seconds).
 *
 * @param int|null $reset Start a new budget of this many seconds.
 * @return float
 */
function nwa_time_left( $reset = null ) {
	static $deadline = 0;
	if ( null !== $reset ) {
		$deadline = microtime( true ) + $reset;
	}
	if ( ! $deadline ) {
		$deadline = microtime( true ) + 25;
	}
	return $deadline - microtime( true );
}

/**
 * Time budget for one audit, based on the PHP time limit.
 *
 * @return int Seconds.
 */
function nwa_time_budget() {
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 120 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	}
	$max = (int) ini_get( 'max_execution_time' );
	if ( $max <= 0 ) {
		return 90;
	}
	// Keep a few seconds for saving, the PDF and the emails.
	return max( 15, min( 90, $max - 8 ) );
}

/**
 * Is this host the website the plugin runs on (with or without www)?
 *
 * @param string $host Host.
 * @return bool
 */
function nwa_is_own_host( $host ) {
	$own = preg_replace( '/^www\./', '', (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	return $own && strtolower( preg_replace( '/^www\./', '', (string) $host ) ) === strtolower( $own );
}

/**
 * Fetch a URL like a normal browser would.
 *
 * Other websites go through wp_safe_remote_get (no private or local addresses). The
 * site's own domain may resolve to an internal address on many hosts, so it uses a
 * normal request. When the SSL certificate chain is incomplete it retries without
 * verification (we only read a public page).
 *
 * @param string $url     URL.
 * @param int    $timeout Seconds.
 * @param int    $limit   Max bytes.
 * @return array|WP_Error
 */
function nwa_fetch( $url, $timeout = 15, $limit = 3145728 ) {
	$timeout = max( 3, min( $timeout, (int) floor( nwa_time_left() ) - 2 ) );
	$own     = nwa_is_own_host( wp_parse_url( $url, PHP_URL_HOST ) );
	$args    = array(
		'timeout'             => $timeout,
		'redirection'         => 5,
		'limit_response_size' => $limit,
		'user-agent'          => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
		'headers'             => array(
			'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language' => 'en-US,en;q=0.9',
			'Accept-Encoding' => 'gzip, deflate',
			'Cache-Control'   => 'no-cache',
		),
	);
	$start    = microtime( true );
	$response = $own ? wp_remote_get( $url, $args ) : wp_safe_remote_get( $url, $args );
	if ( is_wp_error( $response ) && preg_match( '/ssl|certificate|curl error (35|51|58|60|77)/i', $response->get_error_message() ) && nwa_time_left() > 5 ) {
		$args['sslverify'] = false;
		$args['timeout']   = max( 3, min( $timeout, (int) floor( nwa_time_left() ) - 2 ) );
		$response          = $own ? wp_remote_get( $url, $args ) : wp_safe_remote_get( $url, $args );
	}
	$time = microtime( true ) - $start;
	if ( is_wp_error( $response ) ) {
		return $response;
	}
	$final = $url;
	if ( isset( $response['http_response'] ) && is_object( $response['http_response'] ) && method_exists( $response['http_response'], 'get_response_object' ) ) {
		$obj = $response['http_response']->get_response_object();
		if ( ! empty( $obj->url ) ) {
			$final = $obj->url;
		}
	}
	return array(
		'code'    => (int) wp_remote_retrieve_response_code( $response ),
		'body'    => (string) wp_remote_retrieve_body( $response ),
		'headers' => wp_remote_retrieve_headers( $response ),
		'time'    => $time,
		'url'     => $final,
	);
}

/**
 * Does a response look like a real web page (not a firewall challenge)?
 *
 * @param array|WP_Error $page Response.
 * @return bool
 */
function nwa_is_real_page( $page ) {
	if ( is_wp_error( $page ) || $page['code'] >= 400 || strlen( trim( $page['body'] ) ) < 200 ) {
		return false;
	}
	$head = strtolower( substr( $page['body'], 0, 20000 ) );
	if ( false === strpos( $head, '<html' ) && false === strpos( $head, '<body' ) && false === strpos( $head, '<head' ) ) {
		return false;
	}
	// Bot protection pages (Cloudflare, Sucuri, Imunify and similar).
	return ! preg_match( '/(just a moment\.\.\.|cf-browser-verification|cf_chl_|challenge-platform|attention required! \| cloudflare|sucuri website firewall|imunify360|ddos protection by|checking your browser)/', $head );
}

/**
 * Build a check.
 *
 * @param string $label  Label.
 * @param string $status pass|warn|fail.
 * @param int    $weight Importance 1 to 3.
 * @param string $found  What we found.
 * @param string $fix    What to do (empty for passes).
 * @return array
 */
function nwa_check( $label, $status, $weight, $found, $fix = '' ) {
	return array(
		'label'  => $label,
		'status' => $status,
		'weight' => $weight,
		'found'  => $found,
		'fix'    => 'pass' === $status ? '' : $fix,
	);
}

/**
 * Run a full audit. Never fails: when the page can not be read directly it tries
 * other addresses, then Google PageSpeed, and finally builds a quick base report.
 *
 * @param string $url URL.
 * @return array { ok, url, final_url, fetched, mode, notes, stats, categories{ key => { score, checks } }, overall, grade }
 */
function nwa_run_audit( $url ) {
	nwa_time_left( nwa_time_budget() );
	$host  = (string) wp_parse_url( $url, PHP_URL_HOST );
	$path  = (string) wp_parse_url( $url, PHP_URL_PATH );
	$query = (string) wp_parse_url( $url, PHP_URL_QUERY );
	$rest  = ( $path ? $path : '/' ) . ( $query ? '?' . $query : '' );
	$bare  = preg_replace( '/^www\./', '', $host );
	$tries = array_values(
		array_unique(
			array(
				$url,
				'https://' . $host . $rest,
				'https://' . ( $bare === $host ? 'www.' . $host : $bare ) . $rest,
				'http://' . $host . $rest,
			)
		)
	);

	$notes   = array();
	$blocked = false;
	$page    = null;
	foreach ( $tries as $try ) {
		if ( nwa_time_left() < 6 ) {
			break;
		}
		$response = nwa_fetch( $try, 15 );
		if ( nwa_is_real_page( $response ) ) {
			$page = $response;
			break;
		}
		if ( is_wp_error( $response ) ) {
			$notes[] = $try . ': ' . $response->get_error_message();
		} else {
			$notes[] = $try . ': HTTP ' . $response['code'] . ( $response['code'] < 400 ? ' (firewall or empty page)' : '' );
			if ( in_array( $response['code'], array( 401, 403, 406, 429, 503 ), true ) || $response['code'] < 400 ) {
				$blocked = true;
			}
		}
	}

	if ( $page ) {
		$result          = nwa_analyze_page( $page, $url );
		$result['mode']  = 'full';
		$result['notes'] = $notes;
		return $result;
	}

	// Plan B: Google PageSpeed Insights reads the site from Google's servers.
	$psi = nwa_time_left() > 20 ? nwa_pagespeed( $url ) : new WP_Error( 'nwa_time', 'Not enough time left for PageSpeed.' );
	if ( ! is_wp_error( $psi ) ) {
		$result          = nwa_audit_from_pagespeed( $psi, $url );
		$result['notes'] = $notes;
		return $result;
	}
	$notes[] = 'PageSpeed: ' . $psi->get_error_message();

	// Plan C: a quick base report, never an error.
	$result          = nwa_base_report( $url, $blocked );
	$result['notes'] = $notes;
	return $result;
}

/**
 * Analyse a fetched HTML page.
 *
 * @param array  $page Response from nwa_fetch().
 * @param string $url  Requested URL.
 * @return array
 */
function nwa_analyze_page( $page, $url ) {
	$result = array(
		'ok'         => false,
		'error'      => '',
		'url'        => $url,
		'final_url'  => $url,
		'fetched'    => time(),
		'stats'      => array(),
		'categories' => array(),
		'overall'    => 0,
		'grade'      => '',
	);

	$html  = $page['body'];
	$final = $page['url'];
	$host  = (string) wp_parse_url( $final, PHP_URL_HOST );
	$https = 0 === stripos( $final, 'https://' );

	// Parse the HTML.
	$dom = new DOMDocument();
	libxml_use_internal_errors( true );
	$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html, LIBXML_NOWARNING | LIBXML_NOERROR );
	libxml_clear_errors();
	$xp = new DOMXPath( $dom );

	$q     = function ( $expr ) use ( $xp ) {
		$nodes = $xp->query( $expr );
		return false === $nodes ? $xp->query( '//*[false()]' ) : $nodes;
	};
	$first = function ( $expr, $attr = '' ) use ( $q ) {
		$nodes = $q( $expr );
		if ( ! $nodes->length ) {
			return '';
		}
		$node = $nodes->item( 0 );
		return trim( $attr ? $node->getAttribute( $attr ) : $node->textContent );
	};
	$meta  = function ( $name ) use ( $first ) {
		$lower = strtolower( $name );
		$value = $first( "//meta[translate(@name,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='$lower']", 'content' );
		return $value ? $value : $first( "//meta[translate(@property,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='$lower']", 'content' );
	};

	// Visible text.
	$text_dom = $dom->cloneNode( true );
	$txp      = new DOMXPath( $text_dom );
	foreach ( array( '//script', '//style', '//noscript', '//svg', '//template' ) as $expr ) {
		$nodes = $txp->query( $expr );
		if ( $nodes ) {
			foreach ( iterator_to_array( $nodes ) as $node ) {
				$node->parentNode->removeChild( $node );
			}
		}
	}
	$body_nodes = $txp->query( '//body' );
	$text       = $body_nodes && $body_nodes->length ? $body_nodes->item( 0 )->textContent : $text_dom->textContent;
	$text       = trim( preg_replace( '/\s+/u', ' ', html_entity_decode( $text, ENT_QUOTES, 'UTF-8' ) ) );
	$words      = $text ? count( preg_split( '/\s+/u', $text ) ) : 0;

	$images      = $q( '//img' );
	$img_total   = $images->length;
	$img_alt     = 0;
	$img_sized   = 0;
	$img_lazy    = 0;
	$img_modern  = 0;
	$mixed       = 0;
	foreach ( $images as $img ) {
		// An empty alt="" is correct for decorative images, so only a missing alt counts.
		if ( $img->hasAttribute( 'alt' ) ) {
			++$img_alt;
		}
		if ( $img->getAttribute( 'width' ) && $img->getAttribute( 'height' ) ) {
			++$img_sized;
		}
		if ( 'lazy' === strtolower( $img->getAttribute( 'loading' ) ) || $img->getAttribute( 'data-src' ) || $img->getAttribute( 'data-lazy-src' ) ) {
			++$img_lazy;
		}
		$src = strtolower( $img->getAttribute( 'src' ) . ' ' . $img->getAttribute( 'srcset' ) . ' ' . $img->getAttribute( 'data-src' ) );
		if ( preg_match( '/\.(webp|avif)\b/', $src ) ) {
			++$img_modern;
		}
		if ( $https && 0 === strpos( trim( $img->getAttribute( 'src' ) ), 'http://' ) ) {
			++$mixed;
		}
	}
	$picture_sources = $q( "//picture/source[contains(@type,'webp') or contains(@type,'avif')]" )->length;
	if ( $picture_sources ) {
		$img_modern = max( $img_modern, min( $img_total, $picture_sources ) );
	}

	$links       = $q( '//a[@href]' );
	$internal    = 0;
	$external    = 0;
	$social      = 0;
	$contact     = 0;
	$cta         = 0;
	$cta_words   = '/\b(contact|get in touch|quote|book|call|buy|shop|order|get started|start|hire|enquire|inquire|subscribe|sign up|request|free|schedule|talk|whatsapp)\b/i';
	$social_host = '/(facebook|instagram|linkedin|twitter|x\.com|youtube|tiktok|pinterest|behance|dribbble|linktr\.ee)/i';
	foreach ( $links as $a ) {
		$href = trim( $a->getAttribute( 'href' ) );
		if ( '' === $href || '#' === $href[0] || 0 === stripos( $href, 'javascript:' ) ) {
			continue;
		}
		if ( preg_match( '/^(tel:|mailto:)|wa\.me|whatsapp\.com/i', $href ) ) {
			++$contact;
			continue;
		}
		$link_host = (string) wp_parse_url( $href, PHP_URL_HOST );
		if ( '' === $link_host || strcasecmp( preg_replace( '/^www\./', '', $link_host ), preg_replace( '/^www\./', '', $host ) ) === 0 ) {
			++$internal;
		} else {
			++$external;
			if ( preg_match( $social_host, $link_host ) ) {
				++$social;
			}
		}
		if ( preg_match( $cta_words, $a->textContent ) ) {
			++$cta;
		}
	}
	foreach ( $q( '//button' ) as $button ) {
		if ( preg_match( $cta_words, $button->textContent ) ) {
			++$cta;
		}
	}
	if ( preg_match( '/\+?\d[\d\s().-]{8,}\d/', $text ) || preg_match( '/[\w.+-]+@[\w-]+\.[\w.]+/', $text ) ) {
		++$contact;
	}

	$scripts        = $q( '//script[@src]' )->length;
	$inline_scripts = $q( '//script[not(@src)]' )->length;
	$styles         = $q( "//link[contains(translate(@rel,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'stylesheet')]" )->length;
	$blocking       = $q( '//head/script[@src][not(@async)][not(@defer)][not(@type="module")]' )->length;
	$fonts          = array();
	foreach ( $q( "//link[contains(@href,'fonts.googleapis.com')]" ) as $font_link ) {
		if ( preg_match_all( '/family=([^:&|]+)/', urldecode( $font_link->getAttribute( 'href' ) ), $m ) ) {
			foreach ( $m[1] as $family ) {
				$fonts[ strtolower( trim( $family ) ) ] = true;
			}
		}
	}
	foreach ( array( '//script[@src]', "//link[@rel='stylesheet'][@href]" ) as $expr ) {
		foreach ( $q( $expr ) as $node ) {
			$src = $node->getAttribute( 'src' ) ? $node->getAttribute( 'src' ) : $node->getAttribute( 'href' );
			if ( $https && 0 === strpos( $src, 'http://' ) ) {
				++$mixed;
			}
		}
	}

	$size_kb     = strlen( $html ) / 1024;
	$title       = $first( '//title' );
	$description = $meta( 'description' );
	$h1s         = $q( '//h1' );
	$h2          = $q( '//h2' )->length;
	$h3          = $q( '//h3' )->length;
	$paragraphs  = $q( '//p' );
	$headers     = $page['headers'];
	$header      = function ( $name ) use ( $headers ) {
		$value = isset( $headers[ $name ] ) ? $headers[ $name ] : '';
		return is_array( $value ) ? implode( ', ', $value ) : (string) $value;
	};
	$port        = wp_parse_url( $final, PHP_URL_PORT );
	$origin      = ( $https ? 'https://' : 'http://' ) . $host . ( $port ? ':' . $port : '' );

	// Robots.txt and sitemap.
	$robots_txt = nwa_time_left() > 6 ? nwa_fetch( $origin . '/robots.txt', 6, 204800 ) : new WP_Error( 'nwa_time', 'skipped' );
	$has_robots = ! is_wp_error( $robots_txt ) && 200 === $robots_txt['code'] && false !== stripos( $robots_txt['body'], 'user-agent' );
	$sitemap    = $has_robots && preg_match( '/^\s*sitemap:/im', $robots_txt['body'] );
	if ( ! $sitemap ) {
		foreach ( array( '/sitemap_index.xml', '/sitemap.xml', '/wp-sitemap.xml' ) as $path ) {
			if ( nwa_time_left() < 6 ) {
				break;
			}
			$map = nwa_fetch( $origin . $path, 6, 204800 );
			if ( ! is_wp_error( $map ) && 200 === $map['code'] && preg_match( '/<(urlset|sitemapindex)\b/i', $map['body'] ) ) {
				$sitemap = true;
				break;
			}
		}
	}

	// Readability (Flesch reading ease, English).
	$sentences = max( 1, preg_match_all( '/[.!?]+(\s|$)/u', $text ) );
	$syllables = 0;
	foreach ( array_slice( preg_split( '/\s+/u', strtolower( $text ) ), 0, 3000 ) as $word ) {
		$word = preg_replace( '/[^a-z]/', '', $word );
		if ( '' === $word ) {
			continue;
		}
		$count      = preg_match_all( '/[aeiouy]+/', preg_replace( '/(?:[^laeiouy]es|ed|[^laeiouy]e)$/', '', $word ) );
		$syllables += max( 1, $count );
	}
	$sample_words = max( 1, min( $words, 3000 ) );
	$flesch       = $words ? round( 206.835 - 1.015 * ( $words / $sentences ) - 84.6 * ( $syllables / $sample_words ), 0 ) : 0;
	$flesch       = max( 0, min( 100, $flesch ) );

	$long_paragraphs = 0;
	foreach ( $paragraphs as $p ) {
		if ( str_word_count( $p->textContent ) > 120 ) {
			++$long_paragraphs;
		}
	}
	$text_ratio = strlen( $html ) ? round( strlen( $text ) / strlen( $html ) * 100, 1 ) : 0;
	$year       = (int) gmdate( 'Y' );
	preg_match_all( '/(?:©|&copy;|&#169;|copyright)\D{0,20}(\d{4})(?:\s*(?:-|to)\s*(\d{4}))?/iu', $html, $years );
	$copyright  = 0;
	foreach ( array_merge( $years[1], $years[2] ) as $y ) {
		$copyright = max( $copyright, (int) $y );
	}
	$trust = preg_match( '/\b(testimonial|review|rated|stars?|clients? say|trusted by|case stud)/i', $text );

	$pct = function ( $part, $total ) {
		return $total ? round( $part / $total * 100 ) : 100;
	};

	/* --------------------------------------------------------------- SEO */
	$seo   = array();
	$len   = mb_strlen( $title );
	$seo[] = ! $title
		? nwa_check( 'Page title', 'fail', 3, 'No title tag found.', 'Add a unique title of 50 to 60 characters with your main service and location, for example "Wedding Photographer in Leeds | Your Brand".' )
		: ( $len >= 30 && $len <= 65
			? nwa_check( 'Page title', 'pass', 3, sprintf( '"%s" (%d characters).', nwa_cut( $title, 70 ), $len ) )
			: nwa_check( 'Page title', 'warn', 3, sprintf( '"%s" is %d characters.', nwa_cut( $title, 70 ), $len ), $len < 30 ? 'Make the title longer (50 to 60 characters) and include your main keyword.' : 'Shorten the title to about 60 characters so Google does not cut it off.' ) );
	$len   = mb_strlen( $description );
	$seo[] = ! $description
		? nwa_check( 'Meta description', 'fail', 3, 'No meta description found. Google will pick random text from the page.', 'Write a 140 to 160 character description that sells the page and ends with a reason to click.' )
		: ( $len >= 70 && $len <= 165
			? nwa_check( 'Meta description', 'pass', 3, sprintf( '%d characters, a good length.', $len ) )
			: nwa_check( 'Meta description', 'warn', 3, sprintf( 'The description is %d characters.', $len ), 'Aim for 140 to 160 characters with your main keyword and a clear benefit.' ) );
	$seo[] = 1 === $h1s->length
		? nwa_check( 'Main heading (H1)', 'pass', 3, sprintf( 'One H1: "%s"', nwa_cut( rtrim( trim( preg_replace( '/\s+/', ' ', $h1s->item( 0 )->textContent ) ), '.!? ' ), 70 ) ) )
		: ( 0 === $h1s->length
			? nwa_check( 'Main heading (H1)', 'fail', 3, 'No H1 heading found.', 'Add one clear H1 that says what you do and for whom. It is the strongest on page signal after the title.' )
			: nwa_check( 'Main heading (H1)', 'warn', 3, sprintf( '%d H1 headings found.', $h1s->length ), 'Use exactly one H1 per page and turn the others into H2 headings.' ) );
	$seo[] = $h2 >= 2
		? nwa_check( 'Heading structure', 'pass', 2, sprintf( '%d H2 and %d H3 headings organise the page.', $h2, $h3 ) )
		: nwa_check( 'Heading structure', 'warn', 2, sprintf( 'Only %d H2 headings.', $h2 ), 'Break the page into sections with H2 headings that include the words people search for.' );
	$seo[] = $img_total
		? ( $pct( $img_alt, $img_total ) >= 90
			? nwa_check( 'Image alt text', 'pass', 2, sprintf( '%d of %d images have alt text.', $img_alt, $img_total ) )
			: nwa_check( 'Image alt text', $pct( $img_alt, $img_total ) >= 50 ? 'warn' : 'fail', 2, sprintf( 'Only %d of %d images have alt text (%d%%).', $img_alt, $img_total, $pct( $img_alt, $img_total ) ), 'Describe every meaningful image in a few words. It helps Google Images and visitors using screen readers.' ) )
		: nwa_check( 'Image alt text', 'warn', 1, 'No images found on the page.', 'Add a few relevant images with descriptive alt text.' );
	$canonical = $first( "//link[@rel='canonical']", 'href' );
	$seo[]     = $canonical
		? nwa_check( 'Canonical URL', 'pass', 1, 'A canonical tag tells Google which address is the main one.' )
		: nwa_check( 'Canonical URL', 'warn', 1, 'No canonical tag.', 'Add a canonical tag (any SEO plugin does this) to avoid duplicate content issues.' );
	$robots_meta = strtolower( $meta( 'robots' ) );
	$seo[]       = false !== strpos( $robots_meta, 'noindex' )
		? nwa_check( 'Indexing', 'fail', 3, 'The page tells Google NOT to index it (noindex).', 'Remove the noindex tag, unless you really want this page hidden from Google. In WordPress check Settings, Reading.' )
		: nwa_check( 'Indexing', 'pass', 3, 'Search engines are allowed to index this page.' );
	$seo[] = $first( '//html', 'lang' )
		? nwa_check( 'Language tag', 'pass', 1, sprintf( 'Language set to "%s".', $first( '//html', 'lang' ) ) )
		: nwa_check( 'Language tag', 'warn', 1, 'No language set on the page.', 'Add lang="en" (or your language) to the html tag.' );
	$og    = ( $meta( 'og:title' ) ? 1 : 0 ) + ( $meta( 'og:image' ) ? 1 : 0 ) + ( $meta( 'og:description' ) ? 1 : 0 );
	$seo[] = 3 === $og
		? nwa_check( 'Social sharing preview', 'pass', 1, 'Open Graph title, description and image are set.' )
		: nwa_check( 'Social sharing preview', 0 === $og ? 'fail' : 'warn', 1, 0 === $og ? 'No Open Graph tags. Shared links look plain.' : 'Some Open Graph tags are missing.', 'Add Open Graph title, description and image so links shared on WhatsApp, Facebook and LinkedIn look professional.' );
	$schema = $q( "//script[@type='application/ld+json']" )->length || $q( '//*[@itemtype]' )->length;
	$seo[]  = $schema
		? nwa_check( 'Structured data', 'pass', 2, 'Schema markup found, which helps rich results on Google.' )
		: nwa_check( 'Structured data', 'warn', 2, 'No structured data found.', 'Add LocalBusiness or Organization schema so Google can show your details, reviews and opening hours.' );
	$seo[] = $has_robots
		? nwa_check( 'robots.txt', 'pass', 1, 'A robots.txt file is in place.' )
		: nwa_check( 'robots.txt', 'warn', 1, 'No robots.txt file found.', 'Add a robots.txt file that points search engines to your sitemap.' );
	$seo[] = $sitemap
		? nwa_check( 'XML sitemap', 'pass', 2, 'An XML sitemap is available for search engines.' )
		: nwa_check( 'XML sitemap', 'fail', 2, 'No XML sitemap found.', 'Create an XML sitemap (Yoast, Rank Math or WordPress core) and submit it in Google Search Console.' );
	$seo[] = $internal >= 10
		? nwa_check( 'Internal links', 'pass', 1, sprintf( '%d links to other pages on your site.', $internal ) )
		: nwa_check( 'Internal links', 'warn', 1, sprintf( 'Only %d internal links.', $internal ), 'Link to your key service pages from the homepage so visitors and Google find them.' );

	/* ------------------------------------------------------------ Design */
	$design   = array();
	$viewport = $meta( 'viewport' );
	$design[] = false !== stripos( $viewport, 'width=device-width' )
		? nwa_check( 'Mobile friendly', 'pass', 3, 'The page is set up for mobile screens.' )
		: nwa_check( 'Mobile friendly', 'fail', 3, 'No mobile viewport tag. The site may look tiny on phones.', 'Make the site responsive. Over 60% of visitors browse on a phone.' );
	$design[] = $cta >= 2
		? nwa_check( 'Clear call to action', 'pass', 3, sprintf( '%d buttons or links ask the visitor to take a step.', $cta ) )
		: nwa_check( 'Clear call to action', $cta ? 'warn' : 'fail', 3, $cta ? 'Only one call to action found.' : 'No clear call to action found.', 'Add a bold button like "Get a free quote" near the top of the page and repeat it further down.' );
	$design[] = $contact
		? nwa_check( 'Easy to contact', 'pass', 2, 'Phone, email or WhatsApp contact options are visible.' )
		: nwa_check( 'Easy to contact', 'fail', 2, 'No phone number, email or WhatsApp link found on the page.', 'Show a clickable phone number, email or WhatsApp button in the header or footer.' );
	$design[] = $q( "//link[contains(@rel,'icon')]" )->length
		? nwa_check( 'Favicon', 'pass', 1, 'A browser tab icon is set.' )
		: nwa_check( 'Favicon', 'warn', 1, 'No favicon found.', 'Add a favicon so your brand shows in browser tabs and bookmarks.' );
	$design[] = ! $img_total || $pct( $img_sized, $img_total ) >= 80
		? nwa_check( 'Stable layout', 'pass', 2, 'Images reserve their space, so the page does not jump while loading.' )
		: nwa_check( 'Stable layout', 'warn', 2, sprintf( '%d of %d images have no width and height.', $img_total - $img_sized, $img_total ), 'Give images a width and height so the layout does not jump while the page loads (Google calls this CLS).' );
	$design[] = count( $fonts ) <= 3
		? nwa_check( 'Consistent typography', 'pass', 1, count( $fonts ) ? sprintf( '%d web font families, a tidy choice.', count( $fonts ) ) : 'No external font overload.' )
		: nwa_check( 'Consistent typography', 'warn', 1, sprintf( '%d different web font families.', count( $fonts ) ), 'Stick to two font families. It looks more professional and loads faster.' );
	$design[] = $social
		? nwa_check( 'Social proof links', 'pass', 1, sprintf( '%d social media links.', $social ) )
		: nwa_check( 'Social proof links', 'warn', 1, 'No social media links found.', 'Link your active social profiles so visitors can see you are real and active.' );
	$inline   = $q( '//*[@style]' )->length;
	$design[] = $inline <= 60
		? nwa_check( 'Clean build', 'pass', 1, 'The page code is reasonably clean.' )
		: nwa_check( 'Clean build', 'warn', 1, sprintf( '%d inline styles found, a sign of a heavy page builder.', $inline ), 'A lighter theme or cleaner build makes the site faster and easier to keep consistent.' );

	/* ----------------------------------------------------------- Content */
	$content   = array();
	$content[] = $words >= 500
		? nwa_check( 'Amount of content', 'pass', 3, sprintf( 'About %s words of text.', number_format( $words ) ) )
		: nwa_check( 'Amount of content', $words >= 250 ? 'warn' : 'fail', 3, sprintf( 'Only about %s words of text.', number_format( $words ) ), 'Aim for at least 500 useful words: what you do, who it is for, how it works, prices or FAQs.' );
	$content[] = $flesch >= 50
		? nwa_check( 'Easy to read', 'pass', 2, sprintf( 'Readability score %d out of 100, clear and easy.', $flesch ) )
		: nwa_check( 'Easy to read', $flesch >= 30 ? 'warn' : 'fail', 2, sprintf( 'Readability score %d out of 100, quite hard to read.', $flesch ), 'Use shorter sentences and everyday words. Write like you talk to a customer.' );
	$content[] = ( $h2 + $h3 ) >= 4
		? nwa_check( 'Scannable sections', 'pass', 2, sprintf( '%d sub headings make the page easy to scan.', $h2 + $h3 ) )
		: nwa_check( 'Scannable sections', 'warn', 2, 'Few sub headings, so the page is harder to scan.', 'Most visitors scan. Add clear sub headings every few paragraphs.' );
	$content[] = 0 === $long_paragraphs
		? nwa_check( 'Short paragraphs', 'pass', 1, 'Paragraphs are a comfortable length.' )
		: nwa_check( 'Short paragraphs', 'warn', 1, sprintf( '%d very long paragraphs.', $long_paragraphs ), 'Split long paragraphs into 2 to 4 sentences. It is much easier to read on a phone.' );
	$content[] = $img_total >= 3
		? nwa_check( 'Visual content', 'pass', 2, sprintf( '%d images support the text.', $img_total ) )
		: nwa_check( 'Visual content', 'warn', 2, sprintf( 'Only %d images.', $img_total ), 'Add real photos of your work, team or products. They build trust far better than stock photos.' );
	$content[] = $trust
		? nwa_check( 'Trust signals', 'pass', 2, 'Reviews or testimonials are mentioned on the page.' )
		: nwa_check( 'Trust signals', 'fail', 2, 'No reviews, testimonials or ratings found.', 'Show 3 to 6 real customer reviews, ideally with names and photos or your Google rating.' );
	$content[] = $text_ratio >= 10
		? nwa_check( 'Text to code ratio', 'pass', 1, sprintf( '%s%% of the page is readable text.', $text_ratio ) )
		: nwa_check( 'Text to code ratio', 'warn', 1, sprintf( 'Only %s%% of the page is readable text.', $text_ratio ), 'Too much code for little text. A leaner build and more helpful content both help.' );
	$content[] = ! $copyright || $copyright >= $year - 1
		? nwa_check( 'Up to date', 'pass', 1, $copyright ? sprintf( 'Copyright year %d looks current.', $copyright ) : 'No outdated dates spotted.' )
		: nwa_check( 'Up to date', 'warn', 1, sprintf( 'The footer says %d.', $copyright ), 'Update the copyright year. An old year makes visitors wonder if the business is still active.' );

	/* ----------------------------------------------------- Speed & Security */
	$speed    = array();
	$speed[]  = $https
		? nwa_check( 'Secure connection (HTTPS)', 'pass', 3, 'The site loads over HTTPS.' )
		: nwa_check( 'Secure connection (HTTPS)', 'fail', 3, 'The site does not use HTTPS. Browsers show "Not secure".', 'Install a free SSL certificate and redirect all pages to https.' );
	$ttfb     = round( $page['time'], 2 );
	$speed[]  = $ttfb <= 1.0
		? nwa_check( 'Server response', 'pass', 3, sprintf( 'The page arrived in %.2f seconds.', $ttfb ) )
		: nwa_check( 'Server response', $ttfb <= 2.5 ? 'warn' : 'fail', 3, sprintf( 'The page took %.2f seconds to arrive.', $ttfb ), 'Use page caching and good hosting. Aim for under 1 second.' );
	$speed[]  = $size_kb <= 150
		? nwa_check( 'Page weight (HTML)', 'pass', 2, sprintf( 'HTML size %s KB.', $size_kb < 10 ? number_format( $size_kb, 1 ) : (int) round( $size_kb ) ) )
		: nwa_check( 'Page weight (HTML)', $size_kb <= 400 ? 'warn' : 'fail', 2, sprintf( 'HTML size %d KB, quite heavy.', $size_kb ), 'Remove unused sections, plugins and inline code to make the page lighter.' );
	$encoding = strtolower( $header( 'content-encoding' ) );
	$speed[]  = $encoding
		? nwa_check( 'Compression', 'pass', 2, sprintf( 'Files are compressed (%s).', $encoding ) )
		: nwa_check( 'Compression', 'warn', 2, 'No compression detected.', 'Turn on GZIP or Brotli compression on the server or with a caching plugin.' );
	$speed[]  = ( $scripts + $styles ) <= 25
		? nwa_check( 'Number of files', 'pass', 2, sprintf( '%d scripts and %d stylesheets.', $scripts, $styles ) )
		: nwa_check( 'Number of files', ( $scripts + $styles ) <= 45 ? 'warn' : 'fail', 2, sprintf( '%d scripts and %d stylesheets load on this page.', $scripts, $styles ), 'Remove plugins you do not need and combine or defer files.' );
	$speed[]  = $blocking <= 2
		? nwa_check( 'Render blocking scripts', 'pass', 2, 'Scripts do not hold up the first paint.' )
		: nwa_check( 'Render blocking scripts', 'warn', 2, sprintf( '%d scripts block the page from showing.', $blocking ), 'Add defer or async to scripts in the head so content appears sooner.' );
	$speed[]  = ! $img_total || $pct( $img_modern, $img_total ) >= 50
		? nwa_check( 'Modern image formats', 'pass', 2, $img_total ? sprintf( '%d of %d images use WebP or AVIF.', $img_modern, $img_total ) : 'No images to optimise.' )
		: nwa_check( 'Modern image formats', 'warn', 2, sprintf( 'Only %d of %d images use WebP or AVIF.', $img_modern, $img_total ), 'Convert images to WebP. They are usually 30% smaller with the same quality.' );
	$speed[]  = $img_total < 6 || $img_lazy >= 3
		? nwa_check( 'Lazy loading', 'pass', 1, 'Images below the fold wait until they are needed.' )
		: nwa_check( 'Lazy loading', 'warn', 1, 'Images are not lazy loaded.', 'Lazy load images further down the page so the first screen loads faster.' );
	$security = ( $header( 'strict-transport-security' ) ? 1 : 0 ) + ( $header( 'x-content-type-options' ) ? 1 : 0 ) + ( $header( 'x-frame-options' ) || $header( 'content-security-policy' ) ? 1 : 0 );
	$speed[]  = $security >= 2
		? nwa_check( 'Security headers', 'pass', 1, sprintf( '%d of 3 key security headers are set.', $security ) )
		: nwa_check( 'Security headers', 'warn', 1, sprintf( '%d of 3 key security headers are set.', $security ), 'Add HSTS, X-Content-Type-Options and X-Frame-Options headers (a security plugin or your host can do this).' );
	$speed[]  = ! $mixed
		? nwa_check( 'No mixed content', 'pass', 1, 'Everything loads securely.' )
		: nwa_check( 'No mixed content', 'fail', 1, sprintf( '%d files load over insecure http.', $mixed ), 'Update these links to https so browsers do not block them.' );
	$generator = $meta( 'generator' );
	if ( preg_match( '/WordPress\s+[\d.]+/i', $generator ) ) {
		$speed[] = nwa_check( 'Software version hidden', 'warn', 1, sprintf( 'The page shows "%s".', $generator ), 'Hide the WordPress version and keep WordPress, themes and plugins updated.' );
	}

	$groups = array(
		'design'  => $design,
		'seo'     => $seo,
		'content' => $content,
		'speed'   => $speed,
	);
	$total  = 0;
	$weight = 0;
	foreach ( nwa_categories() as $key => $cat ) {
		$score = nwa_score( $groups[ $key ] );
		$result['categories'][ $key ] = array(
			'score'  => $score,
			'checks' => $groups[ $key ],
		);
		$total  += $score * $cat['weight'];
		$weight += $cat['weight'];
	}
	$result['ok']        = true;
	$result['final_url'] = $final;
	$result['overall']   = (int) round( $total / max( 1, $weight ) );
	$result['grade']     = nwa_grade( $result['overall'] );
	$result['title']     = $title;
	$result['stats']     = array(
		'load_time' => $ttfb,
		'size_kb'   => round( $size_kb, 1 ),
		'words'     => $words,
		'images'    => $img_total,
		'links'     => $internal + $external,
		'files'     => $scripts + $styles,
		'https'     => $https,
	);
	return $result;
}

/**
 * Weighted score of a list of checks, 0 to 100.
 *
 * @param array $checks Checks.
 * @return int
 */
function nwa_score( $checks ) {
	$got = 0;
	$max = 0;
	foreach ( $checks as $check ) {
		$value = 'pass' === $check['status'] ? 1 : ( 'warn' === $check['status'] ? 0.5 : 0 );
		$got  += $value * $check['weight'];
		$max  += $check['weight'];
	}
	return $max ? (int) round( $got / $max * 100 ) : 0;
}

/**
 * Letter grade and verdict.
 *
 * @param int $score Score.
 * @return string
 */
function nwa_grade( $score ) {
	if ( $score >= 90 ) {
		return 'A';
	}
	if ( $score >= 75 ) {
		return 'B';
	}
	if ( $score >= 60 ) {
		return 'C';
	}
	if ( $score >= 45 ) {
		return 'D';
	}
	return 'E';
}

/**
 * One line verdict for a score.
 *
 * @param int $score Score.
 * @return string
 */
function nwa_verdict( $score ) {
	if ( $score >= 90 ) {
		return 'Excellent! Your website is in great shape. A few polishing touches will make it even stronger.';
	}
	if ( $score >= 75 ) {
		return 'Good foundation. Fixing the points below can bring noticeably more visitors and enquiries.';
	}
	if ( $score >= 60 ) {
		return 'Decent, but you are leaving visitors and sales on the table. The action plan shows where to start.';
	}
	if ( $score >= 45 ) {
		return 'Your website needs attention. Several issues are costing you rankings and customers.';
	}
	return 'Your website is holding your business back. The good news: most of these fixes are quick wins.';
}

/**
 * Colour state for a score: good, ok or bad.
 *
 * @param int $score Score.
 * @return string
 */
function nwa_state( $score ) {
	return $score >= 75 ? 'good' : ( $score >= 50 ? 'ok' : 'bad' );
}

/**
 * Most important problems first: fails before warnings, heavier weight first.
 *
 * @param array $result Audit result.
 * @param int   $limit  Max items.
 * @return array
 */
function nwa_priorities( $result, $limit = 6 ) {
	$items = array();
	foreach ( $result['categories'] as $key => $cat ) {
		foreach ( $cat['checks'] as $check ) {
			if ( 'pass' !== $check['status'] ) {
				$check['cat']  = $key;
				$check['rank'] = ( 'fail' === $check['status'] ? 10 : 0 ) + $check['weight'] * 2;
				$items[]       = $check;
			}
		}
	}
	usort(
		$items,
		function ( $a, $b ) {
			return $b['rank'] - $a['rank'];
		}
	);
	return array_slice( $items, 0, $limit );
}

/**
 * Strong points: passed checks with the highest weight.
 *
 * @param array $result Audit result.
 * @param int   $limit  Max items.
 * @return array
 */
function nwa_strengths( $result, $limit = 5 ) {
	$items = array();
	foreach ( $result['categories'] as $key => $cat ) {
		foreach ( $cat['checks'] as $check ) {
			if ( 'pass' === $check['status'] ) {
				$check['cat'] = $key;
				$items[]      = $check;
			}
		}
	}
	usort(
		$items,
		function ( $a, $b ) {
			return $b['weight'] - $a['weight'];
		}
	);
	return array_slice( $items, 0, $limit );
}

/**
 * Shorten text.
 *
 * @param string $text Text.
 * @param int    $max  Max characters.
 * @return string
 */
function nwa_cut( $text, $max ) {
	$text = trim( preg_replace( '/\s+/u', ' ', (string) $text ) );
	return mb_strlen( $text ) > $max ? rtrim( mb_substr( $text, 0, $max - 3 ) ) . '...' : $text;
}

/**
 * Turn groups of checks into category scores, an overall score and a grade.
 *
 * @param array $result Result (url, final_url, stats set).
 * @param array $groups design|seo|content|speed => checks.
 * @return array
 */
function nwa_finish( $result, $groups ) {
	$total  = 0;
	$weight = 0;
	foreach ( nwa_categories() as $key => $cat ) {
		$checks = ! empty( $groups[ $key ] ) ? $groups[ $key ] : array( nwa_check( $cat['short'] . ' review', 'warn', 1, 'This part needs a manual check.', 'I will review this part by hand and send you my notes.' ) );
		$score  = nwa_score( $checks );
		$result['categories'][ $key ] = array(
			'score'  => $score,
			'checks' => $checks,
		);
		$total  += $score * $cat['weight'];
		$weight += $cat['weight'];
	}
	$result['ok']      = true;
	$result['error']   = '';
	$result['overall'] = (int) round( $total / max( 1, $weight ) );
	$result['grade']   = nwa_grade( $result['overall'] );
	return $result;
}

/**
 * Ask Google PageSpeed Insights (Lighthouse) about a URL.
 *
 * @param string $url URL.
 * @return array|WP_Error Lighthouse result.
 */
function nwa_pagespeed( $url ) {
	$api = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=' . rawurlencode( $url ) . '&strategy=mobile&category=performance&category=seo&category=accessibility&category=best-practices';
	$key = trim( (string) nwa_opt( 'psi_key' ) );
	if ( $key ) {
		$api .= '&key=' . rawurlencode( $key );
	}
	$response = wp_safe_remote_get(
		$api,
		array(
			'timeout'             => max( 10, min( 70, (int) floor( nwa_time_left() ) - 4 ) ),
			'limit_response_size' => 20971520,
		)
	);
	if ( is_wp_error( $response ) ) {
		return $response;
	}
	$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
	if ( 200 !== (int) wp_remote_retrieve_response_code( $response ) || empty( $data['lighthouseResult']['audits'] ) ) {
		$message = isset( $data['error']['message'] ) ? $data['error']['message'] : 'HTTP ' . wp_remote_retrieve_response_code( $response );
		return new WP_Error( 'nwa_psi', nwa_cut( $message, 200 ) );
	}
	return $data['lighthouseResult'];
}

/**
 * Build our report from a Lighthouse result.
 *
 * @param array  $lh  Lighthouse result.
 * @param string $url URL.
 * @return array
 */
function nwa_audit_from_pagespeed( $lh, $url ) {
	$audits = $lh['audits'];
	$map    = array(
		'is-on-https'               => array( 'speed', 'Secure connection (HTTPS)', 3, 'Install a free SSL certificate and redirect all pages to https.' ),
		'largest-contentful-paint'  => array( 'speed', 'Main content load time (LCP)', 3, 'Compress and resize your hero image, use page caching and good hosting so the main content shows within 2.5 seconds.' ),
		'first-contentful-paint'    => array( 'speed', 'First paint (FCP)', 2, 'Reduce render blocking CSS and JavaScript and turn on caching so something appears quickly.' ),
		'total-blocking-time'       => array( 'speed', 'Responsiveness (TBT)', 2, 'Remove heavy plugins and scripts, and delay third party scripts like chat widgets and trackers.' ),
		'speed-index'               => array( 'speed', 'Speed Index', 2, 'Optimise images and load only what is needed for the first screen.' ),
		'server-response-time'      => array( 'speed', 'Server response', 2, 'Use page caching and good hosting. Aim for under 0.6 seconds.' ),
		'render-blocking-resources' => array( 'speed', 'Render blocking files', 2, 'Defer non critical CSS and JavaScript so content appears sooner.' ),
		'uses-text-compression'     => array( 'speed', 'Compression', 1, 'Turn on GZIP or Brotli compression on the server or with a caching plugin.' ),
		'modern-image-formats'      => array( 'speed', 'Modern image formats', 2, 'Convert images to WebP. They are usually 30% smaller with the same quality.' ),
		'uses-optimized-images'     => array( 'speed', 'Optimised images', 1, 'Compress images before uploading them.' ),
		'offscreen-images'          => array( 'speed', 'Lazy loading', 1, 'Lazy load images further down the page.' ),
		'unused-javascript'         => array( 'speed', 'Unused JavaScript', 1, 'Remove plugins and scripts you do not need on this page.' ),
		'viewport'                  => array( 'design', 'Mobile friendly', 3, 'Make the site responsive. Over 60% of visitors browse on a phone.' ),
		'cumulative-layout-shift'   => array( 'design', 'Stable layout (CLS)', 2, 'Give images, ads and embeds a fixed size so the page does not jump while loading.' ),
		'color-contrast'            => array( 'design', 'Readable colours', 2, 'Increase the contrast between text and background so everyone can read it.' ),
		'target-size'               => array( 'design', 'Easy to tap', 2, 'Make buttons and links at least 48px tall with space between them.' ),
		'tap-targets'               => array( 'design', 'Easy to tap', 2, 'Make buttons and links at least 48px tall with space between them.' ),
		'button-name'               => array( 'design', 'Labelled buttons', 1, 'Give every button a clear text label.' ),
		'errors-in-console'         => array( 'design', 'No browser errors', 1, 'Fix the JavaScript errors so every feature works for visitors.' ),
		'document-title'            => array( 'seo', 'Page title', 3, 'Add a unique title of 50 to 60 characters with your main service and location.' ),
		'meta-description'          => array( 'seo', 'Meta description', 3, 'Write a 140 to 160 character description that sells the page and ends with a reason to click.' ),
		'is-crawlable'              => array( 'seo', 'Indexing', 3, 'Remove the noindex tag or robots block so Google can list this page.' ),
		'http-status-code'          => array( 'seo', 'Page status', 2, 'Make sure the homepage returns a normal 200 status.' ),
		'robots-txt'                => array( 'seo', 'robots.txt', 1, 'Fix the robots.txt file so it is valid and points to your sitemap.' ),
		'canonical'                 => array( 'seo', 'Canonical URL', 1, 'Add a valid canonical tag (any SEO plugin does this).' ),
		'hreflang'                  => array( 'seo', 'Language versions', 1, 'Fix the hreflang tags for your language versions.' ),
		'crawlable-anchors'         => array( 'seo', 'Crawlable links', 1, 'Use normal links with an href so Google can follow them.' ),
		'image-alt'                 => array( 'seo', 'Image alt text', 2, 'Describe every meaningful image in a few words.' ),
		'link-text'                 => array( 'content', 'Descriptive links', 2, 'Replace "click here" and "read more" with words that say where the link goes.' ),
		'heading-order'             => array( 'content', 'Heading order', 2, 'Use headings in order (H1, then H2, then H3) so the page is easy to scan.' ),
		'html-has-lang'             => array( 'content', 'Language set', 1, 'Add lang="en" (or your language) to the html tag.' ),
		'font-size'                 => array( 'content', 'Readable text size', 2, 'Use at least 16px body text on phones.' ),
		'dom-size'                  => array( 'content', 'Page structure', 1, 'Simplify the page: fewer nested sections and page builder wrappers.' ),
	);
	$groups = array(
		'design'  => array(),
		'seo'     => array(),
		'content' => array(),
		'speed'   => array(),
	);
	$clean  = function ( $text ) {
		$text = preg_replace( '/\s*\[Learn[^\]]*\]\([^)]*\)\.?/i', '', (string) $text );
		$text = preg_replace( '/\[([^\]]+)\]\([^)]*\)/', '$1', $text );
		return rtrim( trim( str_replace( '`', '', $text ) ), '. ' );
	};
	$seen   = array();
	foreach ( $map as $id => $info ) {
		if ( empty( $audits[ $id ] ) || isset( $seen[ $info[1] ] ) ) {
			continue;
		}
		$a    = $audits[ $id ];
		$mode = isset( $a['scoreDisplayMode'] ) ? $a['scoreDisplayMode'] : '';
		if ( ! isset( $a['score'] ) || null === $a['score'] || in_array( $mode, array( 'notApplicable', 'informative', 'manual', 'error' ), true ) ) {
			continue;
		}
		$seen[ $info[1] ] = true;
		$status           = $a['score'] >= 0.9 ? 'pass' : ( $a['score'] >= 0.5 ? 'warn' : 'fail' );
		$found            = $clean( $a['title'] ) . ( ! empty( $a['displayValue'] ) ? ': ' . $clean( $a['displayValue'] ) : '' ) . '.';
		$groups[ $info[0] ][] = nwa_check( $info[1], $status, $info[2], $found, $info[3] );
	}
	// Google's own category scores as extra checks.
	$cats  = isset( $lh['categories'] ) ? $lh['categories'] : array();
	$extra = array(
		'performance'    => array( 'speed', 'Google speed score (mobile)', 3, 'Work through the speed fixes above. Images, caching and fewer scripts make the biggest difference.' ),
		'accessibility'  => array( 'design', 'Google accessibility score', 2, 'Improve contrast, labels and tap targets so everyone can use the site.' ),
		'seo'            => array( 'seo', 'Google SEO score', 2, 'Fix the SEO items above to reach 90 or more.' ),
		'best-practices' => array( 'content', 'Google best practices score', 1, 'Fix browser errors, outdated libraries and insecure requests.' ),
	);
	foreach ( $extra as $id => $info ) {
		if ( isset( $cats[ $id ]['score'] ) && null !== $cats[ $id ]['score'] ) {
			$score                = (int) round( $cats[ $id ]['score'] * 100 );
			$status               = $score >= 90 ? 'pass' : ( $score >= 50 ? 'warn' : 'fail' );
			$groups[ $info[0] ][] = nwa_check( $info[1], $status, $info[2], sprintf( 'Google scores this %d out of 100.', $score ), $info[3] );
		}
	}

	$num    = function ( $id ) use ( $audits ) {
		return isset( $audits[ $id ]['numericValue'] ) ? (float) $audits[ $id ]['numericValue'] : null;
	};
	$final  = ! empty( $lh['finalDisplayedUrl'] ) ? $lh['finalDisplayedUrl'] : ( ! empty( $lh['finalUrl'] ) ? $lh['finalUrl'] : $url );
	$result = array(
		'url'       => $url,
		'final_url' => $final,
		'fetched'   => time(),
		'mode'      => 'pagespeed',
		'title'     => '',
		'stats'     => array(
			'load_time' => null !== $num( 'server-response-time' ) ? round( $num( 'server-response-time' ) / 1000, 2 ) : null,
			'size_kb'   => null !== $num( 'total-byte-weight' ) ? round( $num( 'total-byte-weight' ) / 1024 ) : null,
			'words'     => null,
			'images'    => null,
			'links'     => null,
			'files'     => isset( $audits['network-requests']['details']['items'] ) ? count( $audits['network-requests']['details']['items'] ) : null,
			'https'     => 0 === stripos( $final, 'https://' ),
			'lcp'       => null !== $num( 'largest-contentful-paint' ) ? round( $num( 'largest-contentful-paint' ) / 1000, 1 ) : null,
		),
	);
	return nwa_finish( $result, $groups );
}

/**
 * Quick base report when the website can not be scanned at all. Never an error.
 *
 * @param string $url     URL.
 * @param bool   $blocked Did a firewall answer?
 * @return array
 */
function nwa_base_report( $url, $blocked ) {
	$host   = (string) wp_parse_url( $url, PHP_URL_HOST );
	$dns    = filter_var( $host, FILTER_VALIDATE_IP ) || gethostbyname( $host ) !== $host;
	$groups = array(
		'design'  => array(
			nwa_check( 'Design and mobile review', 'warn', 2, 'Needs a manual check, our scanner could not open the page.', 'I will review your design, mobile layout and calls to action by hand and send you my notes.' ),
		),
		'seo'     => array(
			nwa_check( 'SEO review', 'warn', 2, 'Needs a manual check, our scanner could not open the page.', 'I will check your titles, descriptions, headings and Google indexing by hand.' ),
		),
		'content' => array(
			nwa_check( 'Content review', 'warn', 2, 'Needs a manual check, our scanner could not open the page.', 'I will review your text, trust signals and readability by hand.' ),
		),
		'speed'   => array(
			nwa_check( 'Domain', $dns ? 'pass' : 'fail', 2, $dns ? sprintf( '%s is online and resolves correctly.', $host ) : sprintf( '%s does not resolve. Check the spelling or your DNS settings.', $host ), 'Check the domain name and DNS settings with your domain provider.' ),
			nwa_check(
				'Open to search engines and scanners',
				'warn',
				3,
				$blocked ? 'A firewall or security plugin blocked our automated scanner.' : 'The website did not answer our scanner in time.',
				$blocked ? 'Make sure Cloudflare, Wordfence or your host firewall does not block Google and other good bots, or you may lose rankings too.' : 'A slow server can also slow down Google. Check your hosting and caching.'
			),
		),
	);
	$result = array(
		'url'       => $url,
		'final_url' => $url,
		'fetched'   => time(),
		'mode'      => 'basic',
		'title'     => '',
		'stats'     => array(
			'load_time' => null,
			'size_kb'   => null,
			'words'     => null,
			'images'    => null,
			'links'     => null,
			'files'     => null,
			'https'     => 0 === stripos( $url, 'https://' ),
		),
	);
	return nwa_finish( $result, $groups );
}
