<?php
/**
 * Nabia theme functions and definitions.
 *
 * @package Nabia
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'NABIA_VERSION', '2.19.0' );
define( 'NABIA_DIR', get_template_directory() );
define( 'NABIA_URI', get_template_directory_uri() );

require NABIA_DIR . '/inc/defaults.php';
require NABIA_DIR . '/inc/customizer.php';
require NABIA_DIR . '/inc/post-types.php';
require NABIA_DIR . '/inc/template-tags.php';
require NABIA_DIR . '/inc/google-reviews.php';
require NABIA_DIR . '/inc/services.php';
require NABIA_DIR . '/inc/pricing.php';
require NABIA_DIR . '/inc/audit.php';
require NABIA_DIR . '/inc/setup.php';
require NABIA_DIR . '/inc/layout.php';
require NABIA_DIR . '/inc/interlinks.php';
require NABIA_DIR . '/inc/forms.php';
require NABIA_DIR . '/inc/branding.php';

/**
 * Theme setup.
 */
function nabia_setup() {
	load_theme_textdomain( 'nabia', NABIA_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' )
	);
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 80,
			'width'       => 240,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	add_image_size( 'nabia-project', 1200, 900, true );
	add_image_size( 'nabia-card', 800, 600, true );

	register_nav_menus(
		array(
			'primary' => __( 'Primary Menu', 'nabia' ),
			'footer'  => __( 'Footer Menu', 'nabia' ),
		)
	);

	add_editor_style( 'assets/css/editor.css' );
}
add_action( 'after_setup_theme', 'nabia_setup' );

/**
 * Content width.
 */
function nabia_content_width() {
	$GLOBALS['content_width'] = 780;
}
add_action( 'after_setup_theme', 'nabia_content_width', 0 );

/**
 * Widget areas.
 */
function nabia_widgets_init() {
	register_sidebar(
		array(
			'name'          => __( 'Footer', 'nabia' ),
			'id'            => 'footer-1',
			'description'   => __( 'Widgets shown in the footer.', 'nabia' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);
}
add_action( 'widgets_init', 'nabia_widgets_init' );

/**
 * Cache-busting version string for a theme file.
 *
 * @param string $file Path relative to the theme folder.
 * @return string
 */
function nabia_asset_version( $file ) {
	$path = NABIA_DIR . '/' . $file;
	return NABIA_VERSION . ( file_exists( $path ) ? '.' . filemtime( $path ) : '' );
}

/**
 * Enqueue styles and scripts.
 */
function nabia_scripts() {
	// Version = theme version + file time, so browsers and caches always pick up a new upload.
	wp_enqueue_style( 'nabia-style', get_stylesheet_uri(), array(), nabia_asset_version( 'style.css' ) );

	wp_add_inline_style( 'nabia-style', nabia_scheme_css() );

	$deps = array();
	if ( nabia_mod( 'enable_smooth' ) ) {
		// Lenis smooth scrolling (MIT, bundled in assets/js/vendor).
		wp_enqueue_script( 'lenis', NABIA_URI . '/assets/js/vendor/lenis.min.js', array(), '1.3.26', array( 'strategy' => 'defer', 'in_footer' => true ) );
		$deps[] = 'lenis';
	}
	wp_enqueue_script( 'nabia-main', NABIA_URI . '/assets/js/main.js', $deps, nabia_asset_version( 'assets/js/main.js' ), array( 'strategy' => 'defer', 'in_footer' => true ) );
	wp_localize_script(
		'nabia-main',
		'nabiaSettings',
		array(
			'preloader' => (bool) nabia_mod( 'enable_preloader' ),
			'cursor'    => (bool) nabia_mod( 'enable_cursor' ),
			'smooth'    => (bool) nabia_mod( 'enable_smooth' ),
			'formKeys'  => esc_url_raw( rest_url( 'nabia/v1/form-keys' ) ),
			'chatUrl'   => esc_url_raw( nabia_hire_url() ),
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'nabia_scripts' );

/**
 * Preload the self-hosted fonts so headlines render without a flash.
 */
function nabia_preload_fonts() {
	foreach ( array( 'jakarta', 'inter' ) as $font ) {
		printf(
			'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
			esc_url( NABIA_URI . '/assets/fonts/' . $font . '.woff2' )
		);
	}
}
add_action( 'wp_head', 'nabia_preload_fonts', 1 );

/**
 * Favicon colours: follow the colour scheme and the custom accent.
 *
 * @return array ink, accent, second.
 */
function nabia_favicon_colors() {
	$schemes = nabia_color_schemes();
	$scheme  = isset( $schemes[ nabia_mod( 'color_scheme' ) ] ) ? $schemes[ nabia_mod( 'color_scheme' ) ] : reset( $schemes );
	$accent  = sanitize_hex_color( nabia_mod( 'accent_color' ) );
	return array(
		'ink'    => $scheme['ink'],
		'accent' => $accent ? $accent : $scheme['accent'],
		'second' => $accent ? $accent : ( isset( $scheme['second'] ) ? $scheme['second'] : $scheme['accent'] ),
	);
}

/**
 * The "N" monogram favicon as SVG markup.
 *
 * @return string
 */
function nabia_favicon_svg() {
	$c = nabia_favicon_colors();
	return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48">'
		. '<defs><linearGradient id="d" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' . $c['accent'] . '"/><stop offset="1" stop-color="' . $c['second'] . '"/></linearGradient></defs>'
		. '<rect x="1" y="1" width="46" height="46" rx="15" fill="' . $c['ink'] . '"/>'
		. '<path d="M15 34V15.5a1.5 1.5 0 0 1 2.6-1l12.8 15a1.5 1.5 0 0 0 2.6-1V14" fill="none" stroke="#fff" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>'
		. '<circle cx="36.5" cy="36" r="4" fill="url(#d)"/></svg>';
}

/**
 * Favicon set (until a Site Icon is set in Customize → Site Identity):
 * ICO for old browsers, the SVG monogram in your scheme colours, and PNG icons
 * for iPhone / Android home screens (files in assets/favicon).
 */
function nabia_favicon() {
	if ( has_site_icon() ) {
		return;
	}
	$dir = NABIA_URI . '/assets/favicon/';
	printf( '<link rel="icon" href="%s" sizes="32x32">' . "\n", esc_url( $dir . 'favicon.ico' ) );
	echo '<link rel="icon" type="image/svg+xml" href="data:image/svg+xml,' . rawurlencode( nabia_favicon_svg() ) . '">' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG, colours sanitised.
	printf( '<link rel="icon" type="image/png" sizes="192x192" href="%s">' . "\n", esc_url( $dir . 'icon-192.png' ) );
	printf( '<link rel="apple-touch-icon" href="%s">' . "\n", esc_url( $dir . 'apple-touch-icon.png' ) );
}
add_action( 'wp_head', 'nabia_favicon', 2 );

/**
 * Animated favicon: the "N" draws itself in, the dot bounces now and then,
 * and a waving hand calls visitors back when they switch to another tab.
 * Off with Customize → Nabia Theme → General, or when a Site Icon is set.
 */
function nabia_favicon_script() {
	if ( has_site_icon() || ! nabia_mod( 'enable_favicon_anim' ) ) {
		return;
	}
	wp_enqueue_script( 'nabia-favicon', NABIA_URI . '/assets/js/favicon.js', array(), nabia_asset_version( 'assets/js/favicon.js' ), array( 'strategy' => 'defer', 'in_footer' => true ) );
	wp_localize_script( 'nabia-favicon', 'nabiaFavicon', nabia_favicon_colors() );
}
add_action( 'wp_enqueue_scripts', 'nabia_favicon_script' );

/**
 * Print the theme version in the page source, handy to check that an update is live.
 */
function nabia_version_comment() {
	echo '<!-- Nabia theme ' . esc_html( NABIA_VERSION ) . ' -->' . "\n";
}
add_action( 'wp_head', 'nabia_version_comment', 0 );

/**
 * Google Consent Mode v2 defaults: nothing is tracked until the visitor agrees in the
 * cookie popup. Printed first in the head so analytics tags loaded later respect it.
 */
function nabia_consent_defaults() {
	if ( ! nabia_mod( 'enable_cookies' ) ) {
		return;
	}
	?>
	<script>
	window.dataLayer = window.dataLayer || [];
	function gtag(){dataLayer.push(arguments);}
	(function () {
		var m = document.cookie.match(/(?:^|; )nabia_consent=([^;]+)/);
		var c = m ? decodeURIComponent(m[1]) : '';
		var a = c.indexOf('a1') > -1 ? 'granted' : 'denied';
		var k = c.indexOf('m1') > -1 ? 'granted' : 'denied';
		gtag('consent', 'default', { analytics_storage: a, ad_storage: k, ad_user_data: k, ad_personalization: k, wait_for_update: 500 });
	})();
	</script>
	<?php
}
add_action( 'wp_head', 'nabia_consent_defaults', 1 );

/**
 * Add a class when JS runs so reveal animations never hide content for no-JS visitors.
 */
function nabia_js_class() {
	echo "<script>document.documentElement.classList.add('js');</script>\n";
}
add_action( 'wp_head', 'nabia_js_class', 0 );

/**
 * Body classes.
 *
 * @param array $classes Body classes.
 * @return array
 */
function nabia_body_classes( $classes ) {
	if ( is_front_page() ) {
		$classes[] = 'is-home';
	}
	return $classes;
}
add_filter( 'body_class', 'nabia_body_classes' );

/**
 * Shorter excerpts.
 */
function nabia_excerpt_length() {
	return 22;
}
add_filter( 'excerpt_length', 'nabia_excerpt_length' );

function nabia_excerpt_more() {
	return '&hellip;';
}
add_filter( 'excerpt_more', 'nabia_excerpt_more' );
